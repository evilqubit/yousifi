
       

        <script>window.jQuery || document.write('<script src="/js/jquery/jquery-1.10.1.min.js"><\/script>')</script>
        
        
        <script src="/js/jquery/canvas_area_draw/jquery.canvasAreaDraw.js"></script>
        
        
        <script src="/js/jquery/bootstrap/bootstrap.min.js"></script>
        <script src="/js/jquery/nicescroll/jquery.nicescroll.min.js"></script>



<script>



paceOptions = {
  elements: {
    selectors: ['#main-content']
  }
};
	
</script>



<script src="/js/jquery/jstree/jstree.js"></script>
<script type="text/javascript" src="/js/jquery/lightbox/js/lightbox.js"></script>
<script type="text/javascript" src="/js/jquery/uploadify/jquery.uploadify.js"></script> 
<!--  required js               -->
<script type="text/javascript" src="/js/ckeditor/ckeditor.js"></script> 
<script type="text/javascript" src="/js/ckfinder/ckfinder.js"></script>
<script type="text/javascript" src="/js/jquery/jquery-tags-input/jquery.tagsinput.min.js"></script>   
<script src="/js/jquery/prettyPhoto/js/jquery.prettyPhoto.js"></script> 
<script src="/js/jquery/mix/jquery.mixitup.js"></script> 
<script src="/js/jquery/jquery-ui/jquery-ui.min.js"></script> 
<script type="text/javascript" src="/js/jquery/jquery-validation/dist/jquery.validate.min.js"></script>
<script type="text/javascript" src="/js/jquery/jquery-validation/dist/additional-methods.min.js"></script>
<script src="/js/jquery/jcrop/js/jquery.Jcrop.min.js"></script>


<!-- <script src="/js/jquery/uploadify/jquery.uploadify.min.js" type="text/javascript"></script>

<script type="text/javascript" src="/js/jquery/timepicker/dist/jquery-ui-timepicker-addon.min.js"></script> -->
<script type="text/javascript" src="/js/jquery/data-tables/jquery.dataTables.js"></script>
<script type="text/javascript" src="/js/jquery/data-tables/DT_bootstrap.js"></script>
<script src="/js/jquery/timeago/timeago.js" type="text/javascript"></script>



<script src="/js/jquery/pace/pace.min.js?asASDASDSas" type="text/javascript"></script>
<script src="/js/jquery/canvasjs/canvasjs.min.js"></script>
<script src="/js/jquery/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="/js/jquery/chosen/chosen.jquery.js" type="text/javascript"></script>
 <script src="/js/jquery/AYS/jquery.are-you-sure.js"></script>
 
 <script src="/js/jquery/multiselect/jquery.multiselect.js"></script>
 <script src="/js/jquery/multiselect/jquery.multiselect.filter.js"></script>
 
 <script src="/js/jquery/jwplayer/jwplayer.js"></script>
 
 

 <script src="/js/user_interface/popup_window/jquery.popupoverlay.js"></script>
 


 <script src="/js/admin/default.js"></script>     
<script type="text/javascript"></script>
 
