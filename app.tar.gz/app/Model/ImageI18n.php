<?php
class ImageI18n extends AppModel {
	public $name = "ImageI18n";
	public $useTable = "images_i18n";
	public $displayField = "field";
}