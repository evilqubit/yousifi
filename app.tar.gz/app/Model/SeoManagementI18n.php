<?php
class SeoManagementI18n extends AppModel{
	var $name = 'SeoManagementI18n';
	var $useTable = 'seo_managements_i18n';
 	var $displayField = 'field';
	

}
?>