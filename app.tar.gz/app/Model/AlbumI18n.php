<?php
class AlbumI18n extends AppModel {
	public $name = "AlbumI18n";
	public $useTable = "albums_i18n";
	public $displayField = "field";
}