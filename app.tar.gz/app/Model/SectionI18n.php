<?php
class SectionI18n extends AppModel {
	public $name = "SectionI18n";
	public $useTable = "sections_i18n";
	public $displayField = "field";
}