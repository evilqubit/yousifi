<?php
class BannerI18n extends AppModel {
	public $name = "BannerI18n";
	public $useTable = "banners_i18n";
	public $displayField = "field";
}
