<?php
class DynamicPageI18n extends AppModel {
	public $name = "DynamicPageI18n";
	public $useTable = "dynamic_pages_i18n";
	public $displayField = "field";
	
	
	
	
	
	
}