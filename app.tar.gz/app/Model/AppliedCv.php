<?php 
class AppliedCv extends AppModel {
	var $name = "AppliedCv";
	var $useTable = 'applied_cvs';
	var $actsAs = array("Containable");
	var $locale = "eng";
}
?>