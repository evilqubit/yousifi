<?php
class JobI18n extends AppModel {
	public $name = "JobI18n";
	public $useTable = "jobs_i18n";
	public $displayField = "field";
}