<?php
class CategoryI18n extends AppModel {
	public $name = "CategoryI18n";
	public $useTable = "categories_i18n";
	public $displayField = "field";
}
