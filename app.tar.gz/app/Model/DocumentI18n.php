<?php
class DocumentI18n extends AppModel {
	public $name = "DocumentI18n";
	public $useTable = "documents_i18n";
	public $displayField = "field";
}