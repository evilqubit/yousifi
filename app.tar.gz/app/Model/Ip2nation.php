<?php 
class Ip2nation extends AppModel {
	var $name = "Ip2nation";
	var $useTable = 'ip2nation';

}
?>