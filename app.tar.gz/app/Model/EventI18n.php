<?php
class EventI18n extends AppModel {
	public $name = "EventI18n";
	public $useTable = "events_i18n";
	public $displayField = "field";
}