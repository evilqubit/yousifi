<?php
class ContactDepartmentI18n extends AppModel {
	public $name = "ContactDepartmentI18n";
	public $useTable = "contact_departments_i18n";
	public $displayField = "field";
}