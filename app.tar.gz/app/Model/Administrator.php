<?php
class Administrator extends AppModel
{
	var $name = 'Administrator';

}
?>